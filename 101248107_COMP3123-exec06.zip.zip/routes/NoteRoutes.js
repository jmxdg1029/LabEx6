
const NoteModel = require('../models/NotesModel.js');
const express = require('express');
const router = express.Router();



//TODO - Create a new Note
//http://mongoosejs.com/docs/api.html#document_Document-save


router.post('/notes', async(req, res) => {
    //TODO - Write your code here to save the note
    const notes = new NoteModel(req.body)
    // Validate request
    if(!req.body) {
        return res.status(400).send({
            message: "Note content can not be empty"
        });
    }
    try{
        await notes.save()
        res.status(200).send(notes)
    } catch (err){
        res.status(500).send({ "error": err.toString()})
    }
});

//TODO - Retrieve all Notes
//http://mongoosejs.com/docs/api.html#find_find

router.get('/notes', (req, res) => {
    // Validate request
    if(!req.body) {
        return res.status(400).send({
            message: "Note content can not be empty"
        });
    }
    //TODO - Write your code here to returns all note
    NoteModel.find({}, (err,notes) => {
        if (err) res.send({"err":err.toString()})
        res.send(notes)
    })
});

//TODO - Retrieve a single Note with noteId
//http://mongoosejs.com/docs/api.html#findbyid_findById

router.get('/notes/:noteId', (req, res) => {
    
    //TODO - Write your code here to return onlt one note using noteid
    NoteModel.findById(req.params.noteId, (err, note) => {
        if (err) res.send({"error": err.toString()})
        res.send(note)
    })
});

//TODO - Update a Note with noteId
//http://mongoosejs.com/docs/api.html#findbyidandupdate_findByIdAndUpdate

router.put('/notes/:noteId', (req, res) => {
    // Validate request
    if(!req.body) {
        return res.status(400).send({
            message: "Note content can not be empty"
        });
    }
    //TODO - Write your code here to update the note using noteid
    NoteModel.findByIdAndUpdate(req.params.noteId, { ...req.body, noteTitle: "new title" }, {new: true}, (err, note) => {
        if(err) res.send({"error": err.toString()})
        res.send(note)
    })
});

//TODO - Delete a Note with noteId
//http://mongoosejs.com/docs/api.html#findbyidandremove_findByIdAndRemove

router.delete('/notes/:noteId', (req, res) => {
    // Validate request
    if(!req.body) {
        return res.status(400).send({
            message: "Note content can not be empty"
        });
    }
    //TODO - Write your code here to delete the note using noteid
    NoteModel.findByIdAndDelete(req.params.noteId, (err,note) =>{
        if (err) res.send({"error": err.toString()})
        res.send(req.params.noteId + " is deleted")
    })
});

module.exports = router;